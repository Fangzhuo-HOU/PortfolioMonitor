import pandas as pd
# import datatime
import os
porfolio_files_path = r'C:\Users\ChinaQuant\Desktop\PorfolioMonitor\PorfolioMonitor\porfolio_files'
porfolios = os.listdir(porfolio_files_path)
porfolios_file = pd.DataFrame()
for i in porfolios:
    temp_df = pd.read_csv(porfolio_files_path+'\\'+i)
    temp_df['flag'] = str(i.split('.')[0])
    temp_df['base'] = str(i[:2])
    porfolios_file = porfolios_file.append(temp_df)

