import pandas as pd

if __name__ == '__main__':
    flag = 'HS300'

    stk_infos = pd.read_pickle(r'C:\Users\SUSTC\Desktop\程序\PorfolioMonitor\data\daily_data.pickle')
    stk_infos['weighted_rate'] = stk_infos.apply(
        lambda x: float(x['change_rate']) * float(x['weight']), axis=1)

    stk_infos['weighted_excess_rate'] = stk_infos.apply(
        lambda x: float(x['excess_rate']) * float(x['weight']), axis=1)

    stk_infos = stk_infos[stk_infos['flag'] == flag]

    weighted_ratio = stk_infos.groupby(by='time_stamp').agg(
        {'weighted_rate': 'mean', 'weighted_excess_rate': 'mean'}).reset_index()

    ind_ratio = stk_infos.groupby(by=['time_stamp', 'ind']).agg(
        {'weighted_rate': 'mean', 'weighted_excess_rate': 'mean'}).reset_index()

