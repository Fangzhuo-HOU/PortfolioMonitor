import warnings
import pandas as pd
import requests

warnings.filterwarnings('ignore')


def update_market_information(time_stamp, data_file):
    porfolios = pd.read_pickle('E:\CRS\PorfolioMonitor\data\porfolios.pickle')

    url = 'http://hq.sinajs.cn/list='
    for index, row in porfolios.iterrows():
        url = url + str(row['stkcd']) + ','

    r = requests.get(url)
    stk_infos = pd.DataFrame(r.text.split('\n'), columns=['all_info'])
    stk_infos = stk_infos[:-1]

    stk_infos['stkcd'] = stk_infos.apply(lambda x: x['all_info'][11:19], axis=1)
    stk_infos['metrics'] = stk_infos.apply(lambda x: x['all_info'][21:-2], axis=1)
    stk_infos['close_price'] = stk_infos.apply(lambda x: x['metrics'].split(',')[2], axis=1)
    stk_infos['now_price'] = stk_infos.apply(lambda x: x['metrics'].split(',')[3], axis=1)
    stk_infos['time'] = stk_infos.apply(lambda x: x['metrics'].split(',')[31], axis=1)
    stk_infos['change_rate'] = stk_infos.apply(
        lambda x: ((float(x['now_price']) - float(x['close_price'])) / float(x['close_price'])) * 100, axis=1)

    stk_infos = stk_infos[['stkcd', 'change_rate']]

    porfolios = pd.merge(left=porfolios, right=stk_infos, on='stkcd').drop_duplicates()
    porfolios['time_stamp'] = time_stamp

    # 沪深300
    hs300index_url = requests.get('http://hq.sinajs.cn/list=s_sh000300')
    hs300index_rate = float(str(hs300index_url.text).split(',')[-3])

    # 中证500
    zz500index_url = requests.get('http://hq.sinajs.cn/list=s_sh000905')
    zz500index_rate = float(str(zz500index_url.text).split(',')[-3])

    final_porfolio_hs = porfolios[porfolios['base'] == 'HS']
    final_porfolio_zz = porfolios[porfolios['base'] == 'ZZ']

    final_porfolio_hs['excess_rate'] = final_porfolio_hs.apply(
        lambda x: (float(x['change_rate']) - float(hs300index_rate)), axis=1)
    final_porfolio_zz['excess_rate'] = final_porfolio_zz.apply(
        lambda x: (float(x['change_rate']) - float(zz500index_rate)), axis=1)

    final_porfolio = final_porfolio_hs.append(final_porfolio_zz)

    result = pd.read_pickle(data_file)
    result = result.append(final_porfolio)
    result.to_pickle(data_file)


if __name__ == '__main__':
    update_market_information(1, r'E:\CRS\PorfolioMonitor\data\daily_data.pickle')
