import datetime
import time
from functools import lru_cache

from os.path import dirname, join
from bokeh.core.property.primitive import Null
import pandas as pd
import requests

from bokeh.models import Axis, HoverTool, Panel, Tabs
from bokeh.models import Button
from bokeh.models import CustomJS
from bokeh.models import DatePicker
from bokeh.models import ColumnDataSource
from bokeh.models import PreText
from bokeh.models import Select

from bokeh.io import curdoc
from bokeh.io import show
import os
from bokeh.layouts import column, row
from bokeh.plotting import figure

from bokeh.models import FileInput
import pandas as pd
import warnings
import datetime

warnings.filterwarnings("ignore")
import warnings
import pandas as pd
import requests

warnings.filterwarnings('ignore')

path = os.path
print(path)
now = datetime.datetime.now()
date = str(now.year) + '_' + str(now.month) +'_' + str(now.day)
print(date)
data_file_path = os.path.abspath('.') + '\\PorfolioMonitor\\data\\daily_data'+'_'+date+'.pickle'
porfolio_files_path = os.path.abspath('.') + '\\PorfolioMonitor\\porfolio_files'
porfolios = os.listdir(porfolio_files_path)
porfolios_file = pd.DataFrame()
for i in porfolios:
    temp_df = pd.read_csv(porfolio_files_path+'\\'+i)
    temp_df['flag'] = str(i.split('.')[0])
    temp_df['base'] = str(i[:2])
    porfolios_file = porfolios_file.append(temp_df)


porfolios_file_path = os.path.abspath('.') + '\\PorfolioMonitor\\data\\porfolios.pickle'


def initialize_market_information(time_stamp, data_file):
    porfolios = porfolios_file

    url = 'http://hq.sinajs.cn/list='
    for index, row in porfolios.iterrows():
        url = url + str(row['stkcd']) + ','

    r = requests.get(url)
    stk_infos = pd.DataFrame(r.text.split('\n'), columns=['all_info'])
    stk_infos = stk_infos[:-1]

    stk_infos['stkcd'] = stk_infos.apply(lambda x: x['all_info'][11:19], axis=1)
    stk_infos['metrics'] = stk_infos.apply(lambda x: x['all_info'][21:-2], axis=1)
    stk_infos['close_price'] = stk_infos.apply(lambda x: x['metrics'].split(',')[2], axis=1)
    stk_infos['now_price'] = stk_infos.apply(lambda x: x['metrics'].split(',')[3], axis=1)
    stk_infos['time'] = stk_infos.apply(lambda x: x['metrics'].split(',')[31], axis=1)
    stk_infos['change_rate'] = stk_infos.apply(
        lambda x: ((float(x['now_price']) - float(x['close_price'])) / float(x['close_price'])) * 100, axis=1)

    stk_infos = stk_infos[['stkcd', 'change_rate']]

    porfolios = pd.merge(left=porfolios, right=stk_infos, on='stkcd').drop_duplicates()
    porfolios['time_stamp'] = time_stamp

    # 沪深300
    hs300index_url = requests.get('http://hq.sinajs.cn/list=s_sh000300')
    hs300index_rate = float(str(hs300index_url.text).split(',')[-3])

    # 中证500
    zz500index_url = requests.get('http://hq.sinajs.cn/list=s_sh000905')
    zz500index_rate = float(str(zz500index_url.text).split(',')[-3])

    final_porfolio_hs = porfolios[porfolios['base'] == 'HS']
    final_porfolio_zz = porfolios[porfolios['base'] == 'ZZ']

    final_porfolio_hs['excess_rate'] = final_porfolio_hs.apply(
        lambda x: (float(x['change_rate']) - float(hs300index_rate)), axis=1)
    final_porfolio_zz['excess_rate'] = final_porfolio_zz.apply(
        lambda x: (float(x['change_rate']) - float(zz500index_rate)), axis=1)

    final_porfolio = final_porfolio_hs.append(final_porfolio_zz)

    final_porfolio.to_pickle(data_file)


if not os.path.exists(data_file_path):
    initialize_market_information(1, data_file_path)


def update_market_information(stamp, data_file):
    porfolios = porfolios_file

    url = 'http://hq.sinajs.cn/list='
    for index, row in porfolios.iterrows():
        url = url + str(row['stkcd']) + ','

    r = requests.get(url)
    stk_infos = pd.DataFrame(r.text.split('\n'), columns=['all_info'])
    stk_infos = stk_infos[:-1]

    stk_infos['stkcd'] = stk_infos.apply(lambda x: x['all_info'][11:19], axis=1)
    stk_infos['metrics'] = stk_infos.apply(lambda x: x['all_info'][21:-2], axis=1)
    stk_infos['close_price'] = stk_infos.apply(lambda x: x['metrics'].split(',')[2], axis=1)
    stk_infos['now_price'] = stk_infos.apply(lambda x: x['metrics'].split(',')[3], axis=1)
    stk_infos['time'] = stk_infos.apply(lambda x: x['metrics'].split(',')[31], axis=1)
    stk_infos['change_rate'] = stk_infos.apply(
        lambda x: ((float(x['now_price']) - float(x['close_price'])) / float(x['close_price'])) * 100, axis=1)

    stk_infos = stk_infos[['stkcd', 'change_rate']]

    porfolios = pd.merge(left=porfolios, right=stk_infos, on='stkcd').drop_duplicates()
    porfolios['time_stamp'] = stamp

    # 沪深300
    hs300index_url = requests.get('http://hq.sinajs.cn/list=s_sh000300')
    hs300index_rate = float(str(hs300index_url.text).split(',')[-3])

    # 中证500
    zz500index_url = requests.get('http://hq.sinajs.cn/list=s_sh000905')
    zz500index_rate = float(str(zz500index_url.text).split(',')[-3])

    final_porfolio_hs = porfolios[porfolios['base'] == 'HS']
    final_porfolio_zz = porfolios[porfolios['base'] == 'ZZ']

    final_porfolio_hs['excess_rate'] = final_porfolio_hs.apply(
        lambda x: (float(x['change_rate']) - float(hs300index_rate)), axis=1)
    final_porfolio_zz['excess_rate'] = final_porfolio_zz.apply(
        lambda x: (float(x['change_rate']) - float(zz500index_rate)), axis=1)

    final_porfolio = final_porfolio_hs.append(final_porfolio_zz)
    # TODO: 在这里修改中午休市代码
    result = pd.read_pickle(data_file)

    now_time = datetime.datetime.now()
    t_0 = datetime.time(9, 30, 00)
    t_1 = datetime.time(11, 30, 00)
    t_2 = datetime.time(13, 30, 00)
    t_4 = datetime.time(15, 00, 00)
    global time_stamp
    if now_time.time() < t_0:
        time_stamp = time_stamp - 1
        return result

    if now_time.time() > t_4:
        time_stamp = time_stamp - 1
        return result



    if ((t_1 < now_time.time()) & (now_time.time() < t_2)):
        time_stamp = time_stamp - 1
        return result
    else:
        result = result.append(final_porfolio)
        result.to_pickle(data_file)
        return result


def calculate_weighted_price(stk_infos, flag):
    # flag = 'HS300'

    # stk_infos = pd.read_pickle(r'C:\Users\SUSTC\Desktop\程序\PorfolioMonitor\data\daily_data.pickle')
    stk_infos['weighted_rate'] = stk_infos.apply(
        lambda x: float(x['change_rate']) * float(x['weight']), axis=1)

    stk_infos['weighted_excess_rate'] = stk_infos.apply(
        lambda x: float(x['excess_rate']) * float(x['weight']), axis=1)

    stk_infos = stk_infos[stk_infos['flag'] == flag]

    weighted_ratio = stk_infos.groupby(by='time_stamp').agg(
        {'weighted_rate': 'sum', 'weighted_excess_rate': 'sum'}).reset_index()

    ind_ratio = stk_infos.groupby(by=['time_stamp', 'ind']).agg(
        {'weighted_rate': 'sum', 'weighted_excess_rate': 'sum'}).reset_index()
    return [weighted_ratio, ind_ratio]


TOOLTIPS = """
    <div>
        <div>
            <span style="font-size: 13px; color: black;"> $name </span>
        </div>
        <div>
            <span style="font-size: 10px; color: #696;">timeStamp: $x{0.} min</span>
        </div>
        <div>
            <span style="font-size: 10px; color: #696;">returnRatio: $y{0.000} %</span>
        </div>
    </div>
"""
frequency = 60000
colors = ['darksalmon', 'darkseagreen', 'darkslateblue', 'darkslategray', 'darkturquoise', 'darkviolet', 'deeppink',
          'deepskyblue',
          'dimgray', 'dimgrey', 'dodgerblue', 'firebrick', 'floralwhite', 'forestgreen', 'fuchsia', 'gainsboro',
          'ghostwhite', 'gold',
          'goldenrod', 'gray', 'green', 'greenyellow', 'grey', 'honeydew', 'hotpink', 'indianred', 'indigo', 'ivory',
          'khaki', 'lavender',
          'lavenderblush', 'lawngreen', 'lemonchiffon', 'lightblue', 'lightcoral', 'lightcyan', 'lightgoldenrodyellow',
          'lightgray', 'lightgreen',
          'lightgrey', 'lightpink', 'lightsalmon', 'lightseagreen', 'lightskyblue', 'lightslategray', 'lightslategrey',
          'lightsteelblue',
          'lightyellow', 'lime', 'limegreen', 'linen', 'magenta', 'maroon', 'mediumaquamarine', 'mediumblue',
          'mediumorchid', 'mediumpurple',
          'mediumseagreen', 'mediumslateblue', 'mediumspringgreen', 'mediumturquoise', 'mediumvioletred',
          'midnightblue', 'mintcream', 'mistyrose', 'moccasin', 'navajowhite', 'navy', 'oldlace', 'olive', 'olivedrab',
          'orange', 'orangered', 'orchid',
          'palegoldenrod', 'palegreen', 'paleturquoise', 'palevioletred', 'papayawhip', 'peachpuff', 'peru', 'pink',
          'plum',
          'powderblue', 'purple', 'rebeccapurple', 'red', 'rosybrown', 'royalblue',
          'saddlebrown', 'salmon', 'sandybrown', 'seagreen', 'seashell', 'sienna', 'silver', 'skyblue', 'slateblue',
          'slategray', 'slategrey', 'snow', 'springgreen', 'steelblue', 'tan', 'teal', 'thistle', 'tomato', 'turquoise',
          'violet', 'wheat', 'white', 'whitesmoke', 'yellow', 'yellowgreen',
          'aliceblue', 'antiquewhite', 'aqua',
          'aquamarine', 'azure', 'beige', 'bisque', 'black', 'blanchedalmond', 'blue', 'blueviolet', 'brown',
          'burlywood', 'cadetblue',
          'chartreuse', 'chocolate', 'coral', 'cornflowerblue', 'cornsilk', 'crimson', 'cyan', 'darkblue', 'darkcyan',
          'darkgoldenrod', 'darkgray',
          'darkgreen', 'darkgrey', 'darkkhaki', 'darkmagenta', 'darkolivegreen', 'darkorange', 'darkorchid', 'darkred',
          'darksalmon',
          'darkseagreen', 'darkslateblue', 'darkslategray', 'darkslategrey', 'darkturquoise', 'darkviolet', 'deeppink',
          'deepskyblue',
          'dimgray', 'dimgrey', 'dodgerblue', 'firebrick', 'floralwhite', 'forestgreen', 'fuchsia', 'gainsboro',
          'ghostwhite', 'gold',
          'goldenrod', 'gray', 'green', 'greenyellow', 'grey', 'honeydew', 'hotpink', 'indianred', 'indigo', 'ivory',
          'khaki', 'lavender']
porfolios_name = ["HS300", "HS300LV", "ZZ500VG", "ZZ500V", "ZZ500G"]

color_index = 0

board1 = PreText(text='上次更新时间:', width=500)

current_time = PreText(text='等待中', width=500)
frequency = PreText(text='更新频率:' + str(frequency / 1000) + 's', width=500)

tools = 'pan,wheel_zoom,xbox_select,reset'

# source = ColumnDataSource(df)
daily_data = pd.read_pickle(data_file_path)

time_stamp = daily_data['time_stamp'].max()

hs300_dfs = (calculate_weighted_price(daily_data, 'HS300'))
hs300lv_dfs = (calculate_weighted_price(daily_data, 'HS300LV'))
zz500vg_dfs = (calculate_weighted_price(daily_data, 'ZZ500VG'))
zz500v_dfs = (calculate_weighted_price(daily_data, 'ZZ500V'))
zz500g_dfs = (calculate_weighted_price(daily_data, 'ZZ500G'))

hs300 = ColumnDataSource(hs300_dfs[0])
hs300lv = ColumnDataSource(hs300lv_dfs[0])
zz500vg = ColumnDataSource(zz500vg_dfs[0])
zz500v = ColumnDataSource(zz500v_dfs[0])
zz500g = ColumnDataSource(zz500g_dfs[0])

porfolios = {'HS300': hs300, 'HS300LV': hs300lv, 'ZZ500VG': zz500vg, 'ZZ500V': zz500v, 'ZZ500G': zz500g}
porfolios_color = ['blue', 'red', 'yellow', 'green', 'purple']

# 创建组合收益率图像
stk_graph = figure(width=1200, height=400,
                   tools=tools, x_axis_type='linear',
                   active_drag="xbox_select", x_range=(1, 240), tooltips=TOOLTIPS)

for key, color in zip(porfolios, porfolios_color):

    stk_graph.line('time_stamp', 'weighted_rate', source=porfolios[str(key)], legend_label=str(key),
                   line_color=str(color), name=str(key))

stk_graph.legend.location = "top_right"
stk_graph.legend.click_policy = "hide"

# 创建组合超额收益率图像
stk_excess_graph = figure(width=1200, height=400,
                          tools=tools, x_axis_type='linear',
                          active_drag="xbox_select", x_range=(1, 240), tooltips=TOOLTIPS)
for key, color in zip(porfolios, porfolios_color):
    stk_excess_graph.line('time_stamp', 'weighted_excess_rate', source=porfolios[str(key)], legend_label=str(key),
                          line_color=str(color), name=str(key))

stk_excess_graph.legend.location = "top_right"
stk_excess_graph.legend.click_policy = "hide"

tab1 = Panel(child=stk_graph, title="组合收益")
tab2 = Panel(child=stk_excess_graph, title="超额收益")

tabs = (Tabs(tabs=[tab1, tab2]))

ind_graph_hs300 = figure(width=1200, height=800,
                         tools=tools, x_axis_type='linear',
                         active_drag="xbox_select", x_range=(1, 240), tooltips=TOOLTIPS)

hs300_ind = (pd.pivot(hs300_dfs[1], index='time_stamp', columns='ind', values='weighted_rate'))

k = hs300_ind.columns
hs300_ind = ColumnDataSource(hs300_ind)

for i in k:
    ind_graph_hs300.line('time_stamp', i, source=hs300_ind, legend_label=str(i), line_color=colors[color_index],name =str(i))
    color_index = color_index + 1

ind_graph_hs300.legend.location = "top_right"
ind_graph_hs300.legend.click_policy = "hide"

ind_graph_hs300lv = figure(width=1200, height=800,
                           tools=tools, x_axis_type='linear',
                           active_drag="xbox_select", x_range=(1, 240), tooltips=TOOLTIPS)

hs300lv_ind = pd.pivot(hs300lv_dfs[1], index='time_stamp', columns='ind', values='weighted_rate')
k = hs300lv_ind.columns
hs300lv_ind = ColumnDataSource(hs300lv_ind)

for i in k:
    ind_graph_hs300lv.line('time_stamp', i, source=hs300lv_ind, legend_label=str(i), line_color=colors[color_index],name =str(i))
    color_index = color_index + 1
ind_graph_hs300lv.legend.location = "top_right"
ind_graph_hs300lv.legend.click_policy = "hide"

ind_graph_zz500vg = figure(width=1200, height=800,
                           tools=tools, x_axis_type='linear',
                           active_drag="xbox_select", x_range=(1, 240), tooltips=TOOLTIPS)

zz500vg_ind = pd.pivot(zz500vg_dfs[1], index='time_stamp', columns='ind', values='weighted_rate')

k = zz500vg_ind.columns
zz500vg_ind = ColumnDataSource(zz500vg_ind)

for i in k:
    ind_graph_zz500vg.line('time_stamp', i, source=zz500vg_ind, legend_label=str(i), line_color=colors[color_index],name =str(i))
    color_index = color_index + 1
ind_graph_zz500vg.legend.location = "top_right"
ind_graph_zz500vg.legend.click_policy = "hide"

ind_graph_zz500v = figure(width=1200, height=800,
                          tools=tools, x_axis_type='linear',
                          active_drag="xbox_select", x_range=(1, 240), tooltips=TOOLTIPS)

zz500v_ind = pd.pivot(zz500v_dfs[1], index='time_stamp', columns='ind', values='weighted_rate')
k = zz500v_ind.columns
zz500v_ind = ColumnDataSource(zz500v_ind)

for i in k:
    ind_graph_zz500v.line('time_stamp', i, source=zz500v_ind, legend_label=str(i), line_color=colors[color_index],name =str(i))
    color_index = color_index + 1

ind_graph_zz500v.legend.location = "top_right"
ind_graph_zz500v.legend.click_policy = "hide"

ind_graph_zz500g = figure(width=1200, height=800,
                          tools=tools, x_axis_type='linear',
                          active_drag="xbox_select", x_range=(1, 240), tooltips=TOOLTIPS)

zz500g_ind = pd.pivot(zz500g_dfs[1], index='time_stamp', columns='ind', values='weighted_rate')
k = zz500g_ind.columns
zz500g_ind = ColumnDataSource(zz500g_ind)

for i in k:
    ind_graph_zz500g.line('time_stamp', i, source=zz500g_ind, legend_label=str(i), line_color=colors[color_index],name =str(i))
    color_index = color_index + 1
ind_graph_zz500g.legend.location = "top_right"
ind_graph_zz500g.legend.click_policy = "hide"

tab4 = Panel(child=ind_graph_hs300, title="HS300")
tab5 = Panel(child=ind_graph_hs300lv, title="HS300LV")
tab6 = Panel(child=ind_graph_zz500vg, title="ZZ500VG")
tab7 = Panel(child=ind_graph_zz500v, title="ZZ500V")
tab8 = Panel(child=ind_graph_zz500g, title="ZZ500G")

tabs2 = (Tabs(tabs=[tab4, tab5, tab6, tab7, tab8]))


def update():
    global time_stamp
    time_stamp = time_stamp + 1
    current_time.text = str(datetime.datetime.now())

    result = update_market_information(time_stamp, data_file_path)

    hs300_temp = calculate_weighted_price(result, 'HS300')
    hs300lv_temp = calculate_weighted_price(result, 'HS300LV')
    zz500vg_temp = calculate_weighted_price(result, 'ZZ500VG')
    zz500v_temp = calculate_weighted_price(result, 'ZZ500V')
    zz500g_temp = calculate_weighted_price(result, 'ZZ500G')

    hs300.data = hs300_temp[0]
    hs300lv.data = hs300lv_temp[0]
    zz500vg.data = zz500vg_temp[0]
    zz500v.data = zz500v_temp[0]
    zz500g.data = zz500g_temp[0]

    hs300_ind.data = pd.pivot(hs300_temp[1], index='time_stamp', columns='ind', values='weighted_rate')
    hs300lv_ind.data = pd.pivot(hs300lv_temp[1], index='time_stamp', columns='ind', values='weighted_rate')
    zz500vg_ind.data = pd.pivot(zz500vg_temp[1], index='time_stamp', columns='ind', values='weighted_rate')
    zz500v_ind.data = pd.pivot(zz500v_temp[1], index='time_stamp', columns='ind', values='weighted_rate')
    zz500g_ind.data = pd.pivot(zz500g_temp[1], index='time_stamp', columns='ind', values='weighted_rate')






row1 = row(board1, current_time, frequency)
row2 = row(tabs)

ind_board = PreText(text='各组合的行业收益率', width=500)
layout = column(row1, row2, ind_board, tabs2)
curdoc().add_root(layout)
curdoc().title = "Porfolio Monitor"
# curdoc().theme = 'dark_minimal'
curdoc().add_periodic_callback(update, 55000)
