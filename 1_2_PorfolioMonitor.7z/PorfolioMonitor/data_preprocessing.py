import pandas as pd 


df = pd.read_pickle(r'E:\CRS\PorfolioMonitor\data\porfolios.pickle')
# del df['index']
print(df)
# df['base'] = df.apply(lambda x: str(x['flag'])[:2]   ,axis=1)
# df.reset_index(inplace = True)
# df.to_pickle(r'E:\CRS\PorfolioMonitor\data\porfolios.pickle')
# df_hs300 = pd.read_csv(r'E:\CRS\PorfolioMonitor\data\HS300.csv')
# df_hs300lv = pd.read_csv(r'E:\CRS\PorfolioMonitor\data\HS300LV.csv')
# df_zz500g = pd.read_csv(r'E:\CRS\PorfolioMonitor\data\ZZ500G.csv')
# df_zz500v = pd.read_csv(r'E:\CRS\PorfolioMonitor\data\ZZ500V.csv')
# df_500vg = pd.read_csv(r'E:\CRS\PorfolioMonitor\data\ZZ500VG.csv')
#
#
# df_hs300['flag'] = 'HS300'
# df_hs300lv['flag'] = 'HS300LV'
# df_zz500g['flag'] = 'ZZ500G'
# df_zz500v['flag'] = 'ZZ500V'
# df_500vg['flag'] = 'ZZ500VG'
#
# df = df_hs300.append(df_hs300lv).append(df_zz500g).append(df_zz500v).append(df_500vg)
#
# print(df.columns)
#
# df.to_pickle(r'E:\CRS\PorfolioMonitor\data\porfolios.pickle')